library(shiny)

googleDocUI <- function(id, title){

   fluidRow(
      tags$head(tags$script(type="module", src="https://unpkg.com/x-frame-bypass")),
      htmlOutput(NS(id, "iframe"))
      )
   }

googleDocServer <- function(input, output, session, url){

  output$iframe <- renderUI({
     htmlText <- tags$iframe(src=url(), height=1000, width="100%")
     #htmlText <- tags$iframe(src=url(), is="x-frame-bypass", height=1000, width="100%")
     htmlText
     })

} # googleDocServer


