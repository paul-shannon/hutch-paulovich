# shinyModules
module wrappers for some useful widgets: igv, plotly, ggplot, cyjShiny, DT
